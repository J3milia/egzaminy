<?php
    $db = mysqli_connect('localhost', 'root', '', 'terminarz');

    $q = "SELECT DISTINCT wpis FROM zadania WHERE dataZadania BETWEEN '2020-07-01' AND '2020-07-07' AND wpis <> '';";
    $r = mysqli_query($db, $q);

        $next_tasks = "";
        while($row = mysqli_fetch_array($r)) {
            $next_tasks .= $row['wpis'] . "; ";
        }

        $q = "SELECT dataZadania, wpis
        FROM zadania
        WHERE miesiac = 'lipiec';";
        $r = mysqli_query($db, $q);
        $kalendarz = mysqli_fetch_all($r, MYSQLI_BOTH);

        mysqli_close($db);
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Zadania na lipec</title>
   <link rel="stylesheet" href="styl6.css">
</head>
<body>

    <header id="baner">
        <section class="baner1">
            <img src="logo1.png" alt="lipec">
        </section>
        <section class="baner2">
            <h1>TERMINARZ</h1>
            <p>najbliższe zadania:<?= $next_tasks ?></p>
        </section>
    </header>

    <main>   
        <?php
             foreach($kalendarz as $k) {
        ?>   
        <section class="kalendarz">
            <h6><?= $k['dataZadania'] ?></h6>
            <p><?= $k['wpis'] ?></p>
        </section>
        <?php
             }
        ?>
    </main>
    <footer>
        <a href="sierpien.html">Terminarz na sierpień</a>
        <p>Strone wykonał: 0000000000000000000000</p>
    </footer>
 
</body>
</html>